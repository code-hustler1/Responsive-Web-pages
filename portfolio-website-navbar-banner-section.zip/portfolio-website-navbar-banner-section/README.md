# Portfolio Website Navbar & Banner Section

A Pen created on CodePen.io. Original URL: [https://codepen.io/sekhar-123/pen/RwYapaG](https://codepen.io/sekhar-123/pen/RwYapaG).

